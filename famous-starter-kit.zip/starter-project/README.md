#famous global seed
> A Seed Project to get started with the global build of Famo.us

##Getting Started

To get started with this project you can choose to either git-clone or [download the zip](https://github.com/Famous/famous-global-seed/archive/master.zip)

open index.html, and start writing code in src/app.js

That's it!!!

## Contributing
All contributions are welcome! The simplest way to show your support for this project is to **"star" it**.

##License
ISC
